/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Isabel Cristina
 */
public class Empresa {
    
    private int idEmpresa;
    private String nombreEmpresa;
    private String representanteLegal;
    private String tipoSociedad;
    private int codCiiu;
    private String celular;
    private String direccion;
    
    public Empresa() {
    }

    public Empresa(int idEmpresa, String nombreEmpresa, String representanteLegal, String tipoSociedad, int codCiiu, String celular, String direccion) {
        this.idEmpresa = idEmpresa;
        this.nombreEmpresa = nombreEmpresa;
        this.representanteLegal = representanteLegal;
        this.tipoSociedad = tipoSociedad;
        this.codCiiu = codCiiu;
        this.celular = celular;
        this.direccion = direccion;
    }
    
       

    @Override
    public String toString() {
        return "Empresa{" + "idEmpresa=" + idEmpresa + ", nombreEmpresa=" + nombreEmpresa + ", representanteLegal=" + representanteLegal + ", tipoSociedad=" + tipoSociedad + ", codCiiu=" + codCiiu + ", celular=" + celular + ", direccion=" + direccion + '}';
    }

    public int getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getRepresentanteLegal() {
        return representanteLegal;
    }

    public void setRepresentanteLegal(String representanteLegal) {
        this.representanteLegal = representanteLegal;
    }

    public String getTipoSociedad() {
        return tipoSociedad;
    }

    public void setTipoSociedad(String tipoSociedad) {
        this.tipoSociedad = tipoSociedad;
    }

    public int getCodCiiu() {
        return codCiiu;
    }

    public void setCodCiiu(int codCiiu) {
        this.codCiiu = codCiiu;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
   
      
    


}
