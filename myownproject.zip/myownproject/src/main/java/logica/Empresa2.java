
package logica;

public class Empresa2 {

    String nombre;
    int codigoEmpresa;
    int numContacto;
    int region;
    int departamento;
    int ciudad;
    int actividadCiiu;
    
    public Empresa2(){
        this.nombre = "";
        this.codigoEmpresa = 0;
        this.numContacto = 0;
        this.region = 0;
        this.departamento = 0;
        this.ciudad = 0;
        this.actividadCiiu=0;

    }
    
    public Empresa2(String nombre, int codigoEmpresa, int numContacto, int region, int departamento, int ciudad, int actividadCiiu) {
        this.nombre = nombre;
        this.codigoEmpresa = codigoEmpresa;
        this.numContacto = numContacto;
        this.region = region;
        this.departamento = departamento;
        this.ciudad = ciudad;
        this.actividadCiiu = actividadCiiu;
    }
    
    @Override
    public String toString(){
        return "Nombre: "+nombre+" Codigo Empresa: "+codigoEmpresa+" Numero de contacto: "+numContacto;
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigoEmpresa() {
        return codigoEmpresa;
    }

    public void setCodigoEmpresa(int codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }

    public int getNumContacto() {
        return numContacto;
    }

    public void setNumContacto(int numContacto) {
        this.numContacto = numContacto;
    }

    public int getRegion() {
        return region;
    }

    public void setRegion(int region) {
        this.region = region;
    }

    public int getDepartamento() {
        return departamento;
    }

    public void setDepartamento(int departamento) {
        this.departamento = departamento;
    }

    public int getCiudad() {
        return ciudad;
    }

    public void setCiudad(int ciudad) {
        this.ciudad = ciudad;
    }

    public int getActividadCiiu() {
        return actividadCiiu;
    }

    public void setActividadCiiu(int actividadCiiu) {
        this.actividadCiiu = actividadCiiu;
    }
    
    
}
